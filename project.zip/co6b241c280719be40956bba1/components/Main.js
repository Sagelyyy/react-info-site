import React from "react"

export default function Main() {
    return <h1>Main component</h1>
}